#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//HW 4 System Calls
//increaments the value of the magic number of the CPU by the value passed in
int sys_incMagic(void){
  int inc; // param passed from user space
  
  if(argint(0, &inc) < 0)
    return -1;
  pushcli(); //disable interupts
  mycpu()->magic += inc;
  popcli(); //enable interupts
  return 0;
}

//get the magic number from the CPU
int sys_getMagic(void){
  int magic; // param passed from user space
  pushcli(); //disable interupts
  magic = mycpu()->magic;
  popcli(); //enable interupts
  return magic; //return value
}

// get the process name stored in PCB
int sys_getProcName(void){
  cprintf(myproc()->name); // print out the name
  return 0;
}

// Modifies the process name
int sys_modProcName(void){  
  char *name;
  if(argstr(0, &name) < 0){ // return if name passed to us is empty or not set
      return -1;
  } 
  // Safe copy name into myproc name with fixed size of 16
  safestrcpy(myproc()->name, name, 16);
  return 0;
}
